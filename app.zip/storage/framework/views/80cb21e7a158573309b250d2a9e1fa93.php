Expense Tracker
<?php /**PATH C:\Users\USER\Desktop\expense-tracker\resources\views/components/application-logo.blade.php ENDPATH**/ ?>